<?
require($_SERVER['DOCUMENT_ROOT'].'/local/modules/xyz.geolocation/admin/xyz_geolocation_list.php');
?>