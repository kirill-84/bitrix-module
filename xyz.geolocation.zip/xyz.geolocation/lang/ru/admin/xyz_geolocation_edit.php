<?
$MESS["EDIT_CITY_TITLE"] = "Редактирование # #ID#";
$MESS["EDIT_CITY_NAME"] = "Город - ";
$MESS["EDIT_CITY_SELECT"] = "Пользователи";
$MESS["xyz_save_error"] = "Ошибка: ";
?>