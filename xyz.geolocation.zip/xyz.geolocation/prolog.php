<?
define("ADMIN_MODULE_NAME", "xyz.geolocation");
?>