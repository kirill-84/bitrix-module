<?php
Bitrix\Main\Loader::registerAutoloadClasses(
	"xyz.geolocation",
	array(
		"xyz\\geolocation\\Test" => "lib/test.php",
	)
);